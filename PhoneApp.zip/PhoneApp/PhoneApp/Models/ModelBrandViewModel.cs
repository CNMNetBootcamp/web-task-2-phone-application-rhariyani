﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace PhoneApp.Models
{
    public class ModelBrandViewModel
    {
        public List<Phone> Phones;
        public SelectList Brand;
        public string PhoneBrand { get; set; }
        public string SearchString { get; set; }
    }
}
