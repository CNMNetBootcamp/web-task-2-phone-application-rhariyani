﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using PhoneApp.Models;

namespace PhoneApp.Views
{
    public class SeedData
    
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new PhoneAppContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<PhoneAppContext>>()))
            {
                // Look for any Phone.
                if (context.Phone.Any())
                {
                    return;   // DB has been seeded
                }

                context.Phone.AddRange(
                    new Phone
                    {
                        Title = "Nokia 5s",
                        Brand = "Nokia",
                        Type = "Screen ",
                        Color = "Black",
                        OppSystem = "Android",
                        Price = 50.00
                    },

                    new Phone
                    {
                        Title = "Smasung S7",
                        Brand = "Smasung",
                        Type = "LCD ",
                        Color = "Silver",
                        OppSystem = "Android",
                        Price = 60.00
                    },

                    new Phone
                    {
                        Title = "Apple XS",
                        Brand = "Apple",
                        Type = "Screen",
                        Color = "Blue",
                        OppSystem ="Ios" ,
                        Price = 100.00
                    },

                    new Phone
                    {
                        Title = "LG 6",
                        Brand = "LG",
                        Type = "LCD",
                        Color = "White",
                        OppSystem ="Ios" ,
                        Price = 12.00
                    }
                );
                context.SaveChanges();
            }
        }
    }
}
